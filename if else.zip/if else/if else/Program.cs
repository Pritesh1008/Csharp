﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace if_else
{
    class Program
    {
        static void Main(string[] args)
        {
            //static condition statement
            int Age = 17;
            if (Age >= 18)
            {
                Console.Write("Adult");
            }
            else
            {
                Console.Write("teenage");
            }
            Console.Read();
        }
    }
}
