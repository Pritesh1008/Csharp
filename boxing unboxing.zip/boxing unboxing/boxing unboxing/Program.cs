﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace box
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            object obj = i;         //boxing
            Console.WriteLine(obj);

            int j = (int)obj;
            Console.Write(j);       //unboxing
            Console.Read();
        }
    }
}
