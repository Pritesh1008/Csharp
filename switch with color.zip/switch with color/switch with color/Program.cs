﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace switch_with_color
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set console color white=1");
            Console.WriteLine("set console color blue=2");
            Console.WriteLine("set console color green=3");
            int n =Convert.ToInt32(Console.ReadLine());
            switch (n)
            {

                case 1: Console.BackgroundColor = ConsoleColor.White;
                    Console.Clear();
                    break;

                case 2: Console.BackgroundColor = ConsoleColor.Blue;
                    Console.Clear();
                    break;

                case 3: Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;

                default: Console.Write("please select 1 2 3");
                    break;
            }
            Console.Read();
         }
    }
}
